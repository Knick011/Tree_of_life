const ext = globalThis.browser ?? globalThis.chrome;

const state = {
  rawPayload: null,
  normalized: null,
  detectedEmr: '',
};

const statusBox = document.getElementById('statusBox');
const pageHint = document.getElementById('pageHint');
const fieldList = document.getElementById('fieldList');
const fillBtn = document.getElementById('fillBtn');
const readBtn = document.getElementById('readBtn');
const loadBtn = document.getElementById('loadBtn');
const openPanelBtn = document.getElementById('openPanelBtn');
const teachBtn = document.getElementById('teachBtn');
const emrSelect = document.getElementById('emrSelect');
const payloadInput = document.getElementById('payloadInput');
const emrModels = globalThis.TOLEmrModels;

const LABELS = {
  medication: 'Medication',
  medicationDisplay: 'Medication',
  drugName: 'Medication',
  instructions: 'Instructions',
  sig: 'Sig',
  quantity: 'Quantity',
  dispenseQuantity: 'Dispense quantity',
  repeats: 'Repeats',
  refills: 'Refills',
  duration: 'Duration',
  indication: 'Indication',
  specialInstruction: 'Indication',
  patientNote: 'Patient note',
  noteToPharmacy: 'Pharmacy note',
  pharmacyNote: 'Pharmacy note',
  route: 'Route',
  frequency: 'Frequency',
  frequencyCode: 'Frequency',
};

const EMR_LABELS = {
  auto: 'Use app setting',
  oscar: 'OSCAR / Juno',
  pssuite: 'PS Suite',
  accuro: 'Accuro',
  medaccess: 'Med Access',
  chr: 'CHR',
  medesync: 'Medesync',
  epic: 'Epic',
  athena: 'Athena',
  eclinicalworks: 'eClinicalWorks',
  nextgen: 'NextGen',
  practicefusion: 'Practice Fusion',
  drchrono: 'DrChrono',
  emis: 'EMIS Web',
  systmone: 'TPP SystmOne',
  vision: 'Vision',
  generic: 'Generic fallback',
};

function getEmrModel(key) {
  return emrModels?.getModel?.(key) || emrModels?.MODELS?.[key] || emrModels?.MODELS?.generic || null;
}

function getLogicalFieldName(fieldName) {
  const aliases = {
    medicationDisplay: 'medication',
    drugName: 'medication',
    instructions: 'sig',
    dispenseQuantity: 'quantity',
    repeats: 'refills',
    specialInstruction: 'indication',
    patientNote: 'indication',
    noteToPharmacy: 'pharmacyNote',
    frequencyCode: 'frequency',
    reasonForRx: 'reasonForRx',
  };
  return aliases[fieldName] || fieldName;
}

function getSelectedEmr() {
  if (emrSelect.value !== 'auto') return emrSelect.value;
  if (state.normalized?.defaultEmr) return state.normalized.defaultEmr;
  if (state.detectedEmr) return state.detectedEmr;
  return 'generic';
}

function getSelectedEmrLabel() {
  return EMR_LABELS[getSelectedEmr()] || getSelectedEmr();
}

function storageGet(key) {
  if (!ext?.storage?.local?.get) return Promise.resolve({});
  try {
    const result = ext.storage.local.get(key);
    if (result && typeof result.then === 'function') return result;
  } catch {
    // Fall through to callback form.
  }
  return new Promise((resolve) => {
    ext.storage.local.get(key, (result) => resolve(result || {}));
  });
}

function storageSet(data) {
  if (!ext?.storage?.local?.set) return Promise.resolve();
  try {
    const result = ext.storage.local.set(data);
    if (result && typeof result.then === 'function') return result;
  } catch {
    // Fall through to callback form.
  }
  return new Promise((resolve) => {
    ext.storage.local.set(data, () => resolve());
  });
}

function queryActiveTab() {
  if (!ext?.tabs?.query) return Promise.resolve([]);
  try {
    const result = ext.tabs.query({ active: true, currentWindow: true });
    if (result && typeof result.then === 'function') return result;
  } catch {
    // Fall through to callback form.
  }
  return new Promise((resolve) => {
    ext.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve(tabs || []));
  });
}

function sendMessage(tabId, message) {
  if (!ext?.tabs?.sendMessage) return Promise.reject(new Error('tabs.sendMessage unavailable'));
  try {
    const result = ext.tabs.sendMessage(tabId, message);
    if (result && typeof result.then === 'function') return result;
  } catch {
    // Fall through to callback form.
  }
  return new Promise((resolve, reject) => {
    ext.tabs.sendMessage(tabId, message, (response) => {
      const runtimeError = ext.runtime?.lastError;
      if (runtimeError) {
        reject(runtimeError);
        return;
      }
      resolve(response);
    });
  });
}

function clearNode(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
}

function appendTextLine(container, text, className = '') {
  const line = document.createElement('div');
  if (className) line.className = className;
  line.textContent = text;
  container.appendChild(line);
}

function setStatus(kind, { title = '', body = '', subtle = '' } = {}) {
  statusBox.className = `status-box status-${kind}`;
  clearNode(statusBox);

  if (title) {
    const strong = document.createElement('strong');
    strong.textContent = title;
    statusBox.appendChild(strong);
  }

  if (body) {
    if (title) statusBox.appendChild(document.createElement('br'));
    statusBox.appendChild(document.createTextNode(body));
  }

  if (subtle) {
    if (title || body) statusBox.appendChild(document.createElement('br'));
    appendTextLine(statusBox, subtle, 'status-subtle');
  }
}

function showEmpty(message) {
  state.rawPayload = null;
  state.normalized = null;
  fieldList.hidden = true;
  clearNode(fieldList);
  fillBtn.disabled = true;
  setStatus('empty', { body: message });
}

function prettifyFieldName(name) {
  return LABELS[name] || name.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, (ch) => ch.toUpperCase());
}

function normalizePayload(parsed, chosenEmr = '') {
  if (!parsed || parsed._tol !== true) return null;

  if (parsed.schemaVersion >= 2 && parsed.canonical) {
    const defaultEmr = parsed.adapter?.type || parsed.canonical.emrType || 'generic';
    const emrType = chosenEmr || defaultEmr;
    const adapterFields = parsed.adapters?.[emrType]?.fields || parsed.adapter?.fields || {};
    return {
      type: 'v2',
      defaultEmr,
      emrType,
      adapterFields,
      canonical: parsed.canonical,
      medicationLabel:
        parsed.canonical.medicationDisplay ||
        adapterFields.medication ||
        adapterFields.drugName ||
        adapterFields.medicationDisplay ||
        '-',
    };
  }

  const defaultEmr = chosenEmr || 'generic';
  return {
    type: 'legacy',
    defaultEmr,
    emrType: defaultEmr,
    adapterFields: {
      medication: parsed.medication,
      sig: parsed.sig,
      quantity: parsed.quantity,
      frequency: parsed.frequency,
      duration: parsed.duration,
      refills: parsed.refills,
      route: parsed.route,
      indication: parsed.condition,
    },
    canonical: {
      medicationDisplay: parsed.medication,
      sig: parsed.sig,
      route: parsed.route,
      frequencyCode: parsed.frequency,
      dispense: { raw: parsed.quantity || '' },
      duration: parsed.duration,
      refills: parsed.refills,
      indication: parsed.condition,
      emrType: defaultEmr,
    },
    medicationLabel: parsed.medication || '-',
  };
}

function renderFieldPreview(normalized) {
  const fields = Object.entries(normalized.adapterFields || {}).filter(([, value]) => value !== '' && value !== null && value !== undefined);
  if (!fields.length) {
    fieldList.hidden = true;
    clearNode(fieldList);
    return;
  }

  fieldList.hidden = false;
  clearNode(fieldList);
  fields.forEach(([name, value]) => {
    const row = document.createElement('div');
    const label = document.createElement('span');
    const val = document.createElement('span');
    row.dataset.field = name;
    label.textContent = prettifyFieldName(name);
    val.className = 'val';
    val.textContent = String(value);
    row.appendChild(label);
    row.appendChild(val);
    fieldList.appendChild(row);
  });
}

// After a fill, mark each previewed field ✓/✗ so the clinician can see at a
// glance what still needs manual entry before signing.
function markFieldResults(missing) {
  const missingSet = (missing || []).map((m) => String(m).toLowerCase());
  fieldList.querySelectorAll('div[data-field]').forEach((row) => {
    const name = row.dataset.field.toLowerCase();
    const label = prettifyFieldName(row.dataset.field).toLowerCase();
    const isMissing = missingSet.some(
      (m) => m === name || m === label || m.includes(name) || label.includes(m),
    );
    row.classList.toggle('field-missed', isMissing);
    row.classList.toggle('field-filled', !isMissing);
  });
}

function clearFieldResults() {
  fieldList.querySelectorAll('div[data-field]').forEach((row) => {
    row.classList.remove('field-missed', 'field-filled');
  });
}

function getMissingRequiredFields(normalized) {
  const model = getEmrModel(getSelectedEmr());
  if (!model?.requiredLogicalFields?.length) return [];

  const present = new Set(
    Object.entries(normalized.adapterFields || {})
      .filter(([, value]) => value !== '' && value !== null && value !== undefined)
      .map(([name]) => getLogicalFieldName(name)),
  );

  return model.requiredLogicalFields.filter((field) => !present.has(field));
}

function showReady(normalized) {
  const missingRequired = getMissingRequiredFields(normalized);
  const subtleParts = [`Target: ${getSelectedEmrLabel()}`];
  if (missingRequired.length) {
    subtleParts.push(`Missing required: ${missingRequired.map((field) => emrModels?.FIELD_LABELS?.[field] || field).join(', ')}`);
  } else {
    subtleParts.push('Required fields present');
  }
  setStatus('ready', {
    title: 'Draft ready to fill',
    body: normalized.medicationLabel,
    subtle: subtleParts.join(' · '),
  });
  renderFieldPreview(normalized);
  fillBtn.disabled = false;
}

function applyPayload(parsed, preferredEmr = '') {
  const normalized = normalizePayload(parsed, preferredEmr);
  if (!normalized) {
    showEmpty('Clipboard or pasted text is not a valid TOL Scribe payload.');
    return;
  }
  state.rawPayload = parsed;
  state.normalized = normalized;
  clearFieldResults();
  showReady(normalized);
}

async function detectCurrentPage() {
  try {
    const [tab] = await queryActiveTab();
    if (!tab?.id) return;
    const response = await sendMessage(tab.id, { action: 'detectEmr' });
    state.detectedEmr = response?.emrType || '';
    const emrLabel = response?.emrLabel || 'Unknown';
    const pageLabel = response?.title || response?.url || 'Active page';
    const payloadLabel = state.normalized?.defaultEmr ? (EMR_LABELS[state.normalized.defaultEmr] || state.normalized.defaultEmr) : '';
    const prefix = payloadLabel ? `Payload: ${payloadLabel} · ` : '';
    pageHint.textContent = `${prefix}Page: ${emrLabel} · ${pageLabel}`;
    if (emrSelect.value === 'auto' && state.normalized) {
      showReady(state.normalized);
    }
  } catch {
    pageHint.textContent = 'Page detection unavailable on this tab.';
  }
}

async function readClipboard() {
  try {
    const text = await navigator.clipboard.readText();
    payloadInput.value = text;
    applyPayload(JSON.parse(text), getSelectedEmr());
  } catch {
    showEmpty('No valid TOL Scribe payload found in the clipboard. Use "Copy for EMR" first.');
  }
}

async function fillActivePage() {
  if (!state.rawPayload || !state.normalized) return;

  try {
    const [tab] = await queryActiveTab();
    if (!tab?.id) {
      setStatus('empty', { title: 'Error', body: 'No active tab found.' });
      return;
    }

    const emrType = getSelectedEmr();
    const response = await sendMessage(tab.id, {
      action: 'fillRx',
      emrType,
      payload: state.rawPayload,
      normalized: normalizePayload(state.rawPayload, emrType),
    });

    if (response?.success) {
      setStatus('ready', {
        title: `Filled ${response.filledCount} field${response.filledCount === 1 ? '' : 's'}`,
        body: response.missing?.length
          ? 'Review the ✗ fields below and complete them in the EMR before signing.'
          : 'All previewed fields were filled. Review in the EMR before signing.',
        subtle: response.missing?.length ? `Missing: ${response.missing.join(', ')}` : '',
      });
      markFieldResults(response.missing || []);
      fillBtn.textContent = 'Filled';
      setTimeout(() => {
        fillBtn.textContent = 'Fill Fields';
      }, 1200);
      return;
    }

    setStatus('empty', {
      title: 'Fill failed',
      body: response?.message || 'No matching fields were found on the current page.',
    });
  } catch {
    setStatus('empty', {
      title: 'Error',
      body: 'Could not reach the page. Refresh the EMR tab and try again.',
    });
  }
}

async function openInlinePanel() {
  try {
    const [tab] = await queryActiveTab();
    if (!tab?.id) {
      setStatus('empty', { title: 'Error', body: 'No active tab found.' });
      return;
    }

    await sendMessage(tab.id, {
      action: 'openInlinePanel',
      emrType: getSelectedEmr(),
      payload: state.rawPayload,
      normalized: state.normalized || normalizePayload(state.rawPayload, getSelectedEmr()),
    });

    setStatus('ready', {
      title: 'Page panel opened',
      body: 'Use the floating TOL panel on the EMR page.',
      subtle: 'This is the fallback when the browser toolbar is hidden.',
    });
  } catch {
    setStatus('empty', {
      title: 'Error',
      body: 'Could not open the page panel. Refresh the EMR tab and try again.',
    });
  }
}

loadBtn.addEventListener('click', () => {
  try {
    applyPayload(JSON.parse(payloadInput.value), getSelectedEmr());
  } catch {
    showEmpty('Pasted text is not valid JSON.');
  }
});

readBtn.addEventListener('click', readClipboard);
fillBtn.addEventListener('click', fillActivePage);
openPanelBtn.addEventListener('click', openInlinePanel);

teachBtn.addEventListener('click', async () => {
  try {
    const tabs = await queryActiveTab();
    const tab = tabs[0];
    if (!tab?.id) {
      setStatus('empty', { title: 'No active tab', body: 'Open the EMR tab and try again.' });
      return;
    }
    await sendMessage(tab.id, { type: 'TOL_RECORDER_START', emrType: getSelectedEmr() });
    setStatus('ready', { title: 'Recorder started', body: 'Switch to the EMR tab and click each prescription field.' });
    window.close();
  } catch {
    setStatus('empty', { title: 'Could not start recorder', body: 'Refresh the EMR tab and try again.' });
  }
});

emrSelect.addEventListener('change', async () => {
  await storageSet({ emrType: emrSelect.value });
  if (state.rawPayload) {
    applyPayload(state.rawPayload, getSelectedEmr());
  }
  await detectCurrentPage();
});

const PUSHED_PAYLOAD_TTL = 4 * 60 * 60 * 1000; // 4 hours

(async () => {
  const stored = await storageGet('emrType');
  if (stored?.emrType) emrSelect.value = stored.emrType;
  await detectCurrentPage();

  // Prefer a payload pushed directly from the web app ("Send to EMR");
  // clipboard stays as the fallback transport.
  const pushed = await storageGet(['tolPushedPayload', 'tolPushedAt']);
  const isFresh = pushed?.tolPushedPayload && Date.now() - (pushed.tolPushedAt || 0) < PUSHED_PAYLOAD_TTL;
  if (isFresh) {
    payloadInput.value = JSON.stringify(pushed.tolPushedPayload, null, 2);
    applyPayload(pushed.tolPushedPayload, getSelectedEmr());
    return;
  }
  await readClipboard();
})();
